import { useState } from 'react'
import { CATEGORIES, PROPERTIES } from './constants.js'
import { fmtHrs, todayStr, weeksSince } from './utils.js'
import { labelSt, inputSt, cardSt, Btn, Tag } from './ui.jsx'

export default function RecurView({ recur, setRecur, setLogs }) {
  const [showForm, setShowForm] = useState(false)
  const [rf, setRf] = useState({ category: '', activity: '', property: PROPERTIES[3], description: '', notes: '', hours: '', minutes: '', startDate: todayStr() })
  const rCat = CATEGORIES.find(c => c.id === rf.category)

  function addRecur() {
    const ms = (parseInt(rf.hours || 0) * 60 + parseInt(rf.minutes || 0)) * 60000
    if (!rf.category || !rf.activity || !ms || !rf.description) return
    setRecur(p => [...p, { id: Date.now(), category: rf.category, activity: rf.activity, property: rf.property, description: rf.description, notes: rf.notes, durationMs: ms, startDate: rf.startDate }])
    setRf({ category: '', activity: '', property: PROPERTIES[3], description: '', notes: '', hours: '', minutes: '', startDate: todayStr() })
    setShowForm(false)
  }

  return (
    <div className="scroll-area" style={{ height: '100%', paddingBottom: 80 }}>
      <div style={{ padding: '16px 16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase', color: '#8A7E6A' }}>Weekly Recurring Tasks</div>
          <div style={{ fontSize: 11, color: '#5A5040', marginTop: 4 }}>Auto-logged every week from start date</div>
        </div>
        <button onClick={() => setShowForm(!showForm)} style={{ background: showForm ? '#2A2820' : '#C8A96E', color: showForm ? '#8A7E6A' : '#0F0E0C', border: 'none', borderRadius: 6, padding: '9px 14px', fontSize: 11, letterSpacing: '0.15em', textTransform: 'uppercase', cursor: 'pointer' }}>
          {showForm ? 'Cancel' : '+ Add'}
        </button>
      </div>

      {showForm && (
        <div style={{ ...cardSt, margin: '16px 16px 8px', borderColor: '#C8A96E' }}>
          <div style={{ fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C8A96E', marginBottom: 14 }}>New Recurring Task</div>

          <label style={labelSt}>Category</label>
          <select value={rf.category} onChange={e => setRf(f => ({ ...f, category: e.target.value, activity: '' }))} style={inputSt}>
            <option value="">— Select —</option>
            {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
          </select>

          <label style={labelSt}>Activity</label>
          <select value={rf.activity} onChange={e => setRf(f => ({ ...f, activity: e.target.value }))} style={inputSt} disabled={!rf.category}>
            <option value="">— Select —</option>
            {(rCat?.activities || []).map(a => <option key={a} value={a}>{a}</option>)}
          </select>

          <label style={labelSt}>Property</label>
          <select value={rf.property} onChange={e => setRf(f => ({ ...f, property: e.target.value }))} style={inputSt}>
            {PROPERTIES.map(p => <option key={p} value={p}>{p}</option>)}
          </select>

          <label style={labelSt}>Start Date</label>
          <input type="date" value={rf.startDate} onChange={e => setRf(f => ({ ...f, startDate: e.target.value }))} style={inputSt} />

          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <label style={labelSt}>Hours / week</label>
              <input type="number" min="0" value={rf.hours} onChange={e => setRf(f => ({ ...f, hours: e.target.value }))} style={inputSt} placeholder="0" />
            </div>
            <div style={{ flex: 1 }}>
              <label style={labelSt}>Minutes / week</label>
              <input type="number" min="0" max="59" value={rf.minutes} onChange={e => setRf(f => ({ ...f, minutes: e.target.value }))} style={inputSt} placeholder="0" />
            </div>
          </div>

          <label style={{ ...labelSt, color: '#C8A96E' }}>★ Description of Work Done <span style={{ color: '#C87E8A' }}>*</span></label>
          <textarea value={rf.description} onChange={e => setRf(f => ({ ...f, description: e.target.value }))} placeholder="e.g. Weekly rent roll review, verify HAP payments, log discrepancies, follow up on late items" style={{ ...inputSt, height: 80, resize: 'none', lineHeight: 1.5 }} />

          <label style={labelSt}>Additional Notes (optional)</label>
          <input type="text" value={rf.notes} onChange={e => setRf(f => ({ ...f, notes: e.target.value }))} style={inputSt} placeholder="Supporting context..." />

          <Btn onClick={addRecur} disabled={!rf.category || !rf.activity || (!rf.hours && !rf.minutes) || !rf.description}>
            Save Recurring Task
          </Btn>
        </div>
      )}

      {!recur.length && !showForm && (
        <div style={{ color: '#5A5040', fontSize: 13, padding: '40px 16px', textAlign: 'center' }}>
          No recurring tasks yet.<br />
          <span style={{ fontSize: 11, color: '#3A3020' }}>Add weekly tasks like rent review, bookkeeping, or walk-throughs.</span>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '8px 16px' }}>
        {recur.map(task => {
          const cat = CATEGORIES.find(c => c.id === task.category)
          const weeks = weeksSince(task.startDate)
          return (
            <div key={task.id} style={{ ...cardSt, padding: '14px 16px', borderLeft: `3px solid ${cat?.color || '#C8A96E'}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 6 }}>
                    <Tag color="#7EB8A4" bg="#1E2820">↻ weekly</Tag>
                    <span style={{ fontSize: 11, color: cat?.color }}>{cat?.icon} {cat?.label}</span>
                  </div>
                  <div style={{ fontSize: 14, color: '#E8E2D8', marginBottom: 3 }}>{task.activity}</div>
                  <div style={{ fontSize: 11, color: '#6A5A4A', marginBottom: 6 }}>{task.property}</div>
                  {task.description && (
                    <div style={{ fontSize: 12, color: '#B8C8B0', lineHeight: 1.5, borderLeft: '2px solid #2A3828', paddingLeft: 10, marginBottom: 6 }}>
                      {task.description}
                    </div>
                  )}
                  <div style={{ fontSize: 10, color: '#4A4030' }}>
                    Since {task.startDate} · {weeks.length} week{weeks.length !== 1 ? 's' : ''} · {fmtHrs(task.durationMs * weeks.length)} hrs total
                  </div>
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 12 }}>
                  <div style={{ fontSize: 20, color: '#C8A96E' }}>{fmtHrs(task.durationMs)}h</div>
                  <div style={{ fontSize: 9, color: '#5A5040', letterSpacing: '0.1em', textTransform: 'uppercase' }}>/ week</div>
                  <button
                    onClick={() => { setRecur(p => p.filter(t => t.id !== task.id)); setLogs(p => p.filter(l => l.recurId !== task.id)) }}
                    style={{ marginTop: 8, background: 'none', border: '1px solid #2A2820', color: '#8A7E6A', cursor: 'pointer', fontSize: 9, padding: '4px 8px', borderRadius: 3, letterSpacing: '0.1em', textTransform: 'uppercase' }}
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
