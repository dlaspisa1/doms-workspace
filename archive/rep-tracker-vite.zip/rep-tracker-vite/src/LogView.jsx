import { useState } from 'react'
import { CATEGORIES, PROPERTIES } from './constants.js'
import { formatDuration, fmtHrs } from './utils.js'
import { labelSt, inputSt, inputErrSt, cardSt, Btn, Tag } from './ui.jsx'

export default function LogView({ logs, setLogs, form, setForm, timer, setTimer, elapsed }) {
  const [descErr, setDescErr] = useState(false)
  const [filterCat, setFilterCat] = useState('all')
  const sCat = CATEGORIES.find(c => c.id === form.category)
  const filtered = filterCat === 'all' ? logs : logs.filter(l => l.category === filterCat)

  function validate() {
    if (!form.description || form.description.trim().length < 10) { setDescErr(true); return false }
    setDescErr(false); return true
  }
  function startTimer() {
    if (!form.category || !form.activity || !validate()) return
    setTimer({ startMs: Date.now(), ...form })
  }
  function stopTimer() {
    if (!timer) return
    setLogs(p => [{ id: Date.now(), ...timer, durationMs: Date.now() - timer.startMs, method: 'timer' }, ...p])
    setTimer(null)
  }
  function addManual() {
    if (!form.category || !form.activity || !validate()) return
    const ms = (parseInt(form.mh || 0) * 60 + parseInt(form.mm || 0)) * 60000
    if (!ms) return
    setLogs(p => [{ id: Date.now(), ...form, durationMs: ms, method: 'manual' }, ...p])
    setForm(f => ({ ...f, mh: '', mm: '', description: '', notes: '' }))
  }

  return (
    <div className="scroll-area" style={{ height: '100%', paddingBottom: 80 }}>
      {/* Entry form */}
      <div style={{ ...cardSt, margin: '16px 16px 12px', borderColor: '#2A3020' }}>
        <div style={{ fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase', color: '#C8A96E', marginBottom: 16 }}>New Entry</div>

        <label style={labelSt}>Date</label>
        <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} style={inputSt} />

        <label style={labelSt}>Category</label>
        <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value, activity: '' }))} style={inputSt}>
          <option value="">— Select category —</option>
          {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
        </select>

        <label style={labelSt}>Activity</label>
        <select value={form.activity} onChange={e => setForm(f => ({ ...f, activity: e.target.value }))} style={inputSt} disabled={!form.category}>
          <option value="">— Select activity —</option>
          {(sCat?.activities || []).map(a => <option key={a} value={a}>{a}</option>)}
        </select>

        <label style={labelSt}>Property</label>
        <select value={form.property} onChange={e => setForm(f => ({ ...f, property: e.target.value }))} style={inputSt}>
          {PROPERTIES.map(p => <option key={p} value={p}>{p}</option>)}
        </select>

        <label style={{ ...labelSt, color: descErr ? '#C87E8A' : '#C8A96E' }}>
          ★ Description of Work Done <span style={{ color: '#C87E8A' }}>*</span>
        </label>
        <textarea
          value={form.description}
          onChange={e => { setForm(f => ({ ...f, description: e.target.value })); if (e.target.value.trim().length >= 10) setDescErr(false) }}
          placeholder="e.g. Reviewed Osborn rent roll, verified HAP payments for units 2 & 4, followed up with Section 8 re unit 3 late payment"
          style={{ ...(descErr ? inputErrSt : inputSt), height: 90, resize: 'none', lineHeight: 1.5 }}
        />
        {descErr && <div style={{ fontSize: 10, color: '#C87E8A', marginTop: 4 }}>Required — describe specifically what you did</div>}

        <label style={labelSt}>Additional Notes (optional)</label>
        <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Supporting context..." style={{ ...inputSt, height: 48, resize: 'none' }} />

        {timer ? (
          <div style={{ marginTop: 16, textAlign: 'center' }}>
            <div style={{ fontSize: 40, color: '#C8A96E', fontVariantNumeric: 'tabular-nums', letterSpacing: '0.05em', marginBottom: 12 }}>
              {formatDuration(elapsed)}
            </div>
            <Btn onClick={stopTimer} variant="red">■ Stop & Save</Btn>
          </div>
        ) : (
          <Btn onClick={startTimer} disabled={!form.category || !form.activity}>▶ Start Timer</Btn>
        )}

        <div style={{ marginTop: 16, borderTop: '1px solid #2A2820', paddingTop: 16 }}>
          <div style={{ fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#5A5040', marginBottom: 10 }}>Or log manually</div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <label style={labelSt}>Hours</label>
              <input type="number" min="0" value={form.mh} onChange={e => setForm(f => ({ ...f, mh: e.target.value }))} style={inputSt} placeholder="0" />
            </div>
            <div style={{ flex: 1 }}>
              <label style={labelSt}>Minutes</label>
              <input type="number" min="0" max="59" value={form.mm} onChange={e => setForm(f => ({ ...f, mm: e.target.value }))} style={inputSt} placeholder="0" />
            </div>
          </div>
          <Btn onClick={addManual} disabled={!form.category || !form.activity} variant="ghost">+ Add Entry</Btn>
        </div>
      </div>

      {/* Filter + log list */}
      <div style={{ padding: '0 16px 10px', display: 'flex', gap: 8, alignItems: 'center' }}>
        <span style={{ fontSize: 10, letterSpacing: '0.15em', textTransform: 'uppercase', color: '#5A5040', flexShrink: 0 }}>{filtered.length} entries</span>
        <select value={filterCat} onChange={e => setFilterCat(e.target.value)} style={{ ...inputSt, fontSize: 11, padding: '7px 32px 7px 10px', flex: 1 }}>
          <option value="all">All categories</option>
          {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
        </select>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '0 16px' }}>
        {!filtered.length && (
          <div style={{ color: '#5A5040', fontSize: 13, padding: '32px 0', textAlign: 'center' }}>
            No entries yet.<br /><span style={{ fontSize: 11 }}>Start a timer or log manually above.</span>
          </div>
        )}
        {filtered.map(log => {
          const cat = CATEGORIES.find(c => c.id === log.category)
          const missingDesc = !log.description || log.description.trim().length < 5
          return (
            <div key={log.id} style={{ ...cardSt, padding: '14px 16px', borderLeft: `3px solid ${cat?.color || '#C8A96E'}`, borderColor: missingDesc ? '#3A2020' : '#2A2820' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap', marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: cat?.color }}>{cat?.icon} {cat?.label}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap', marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: '#8A7E6A' }}>{log.date}</span>
                    {log.method === 'recurring' && <Tag color="#7EB8A4" bg="#1E2820">↻ recurring</Tag>}
                    {log.method === 'manual' && <Tag color="#5A5040" bg="#1A1818">manual</Tag>}
                    {missingDesc && <Tag color="#C87E8A" bg="#2A1818">⚠ needs description</Tag>}
                  </div>
                  <div style={{ fontSize: 14, color: '#E8E2D8', marginBottom: 4 }}>{log.activity}</div>
                  <div style={{ fontSize: 11, color: '#6A5A4A', marginBottom: log.description ? 6 : 0 }}>{log.property}</div>
                  {log.description && (
                    <div style={{ fontSize: 12, color: '#B8C8B0', lineHeight: 1.5, borderLeft: '2px solid #2A3828', paddingLeft: 10 }}>
                      {log.description}
                    </div>
                  )}
                  {log.notes && <div style={{ fontSize: 11, color: '#5A5040', marginTop: 4, fontStyle: 'italic' }}>{log.notes}</div>}
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 12 }}>
                  <div style={{ fontSize: 20, color: '#C8A96E', fontVariantNumeric: 'tabular-nums' }}>{fmtHrs(log.durationMs)}h</div>
                  <button onClick={() => setLogs(p => p.filter(l => l.id !== log.id))} style={{ background: 'none', border: 'none', color: '#3A3020', cursor: 'pointer', fontSize: 20, lineHeight: 1, marginTop: 4, padding: '4px 0' }}>×</button>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
