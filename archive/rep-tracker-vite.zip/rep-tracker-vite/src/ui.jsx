export const labelSt = {
  display: 'block', fontSize: 10, letterSpacing: '0.2em',
  textTransform: 'uppercase', color: '#8A7E6A', marginBottom: 6, marginTop: 14
}

export const inputSt = {
  width: '100%', background: '#0A0908', border: '1px solid #2A2820',
  borderRadius: 6, color: '#E8E2D8', padding: '11px 12px', fontSize: 15, outline: 'none'
}

export const inputErrSt = { ...inputSt, border: '1px solid #C87E8A' }

export const cardSt = {
  background: '#161510', border: '1px solid #2A2820', borderRadius: 10, padding: 20
}

export function Btn({ children, onClick, disabled, variant = 'gold', style = {} }) {
  const bases = {
    gold: { background: disabled ? '#1A1810' : '#C8A96E', color: disabled ? '#3A3020' : '#0F0E0C' },
    ghost: { background: '#1E1C18', color: '#C8A96E' },
    red: { background: '#C87E8A', color: '#0F0E0C' },
    outline: { background: 'transparent', color: '#8A7E6A', border: '1px solid #2A2820' },
  }
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        width: '100%', padding: '13px 16px', border: 'none', borderRadius: 6,
        fontSize: 12, letterSpacing: '0.2em', textTransform: 'uppercase',
        cursor: disabled ? 'not-allowed' : 'pointer', marginTop: 14,
        ...bases[variant], ...style
      }}
    >
      {children}
    </button>
  )
}

export function Tag({ children, color = '#7EB8A4', bg = '#1E2820' }) {
  return (
    <span style={{
      fontSize: 9, background: bg, color,
      letterSpacing: '0.1em', textTransform: 'uppercase', padding: '2px 6px', borderRadius: 3
    }}>
      {children}
    </span>
  )
}
