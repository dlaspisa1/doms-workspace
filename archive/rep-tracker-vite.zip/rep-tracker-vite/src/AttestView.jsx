import { useRef } from 'react'
import { CATEGORIES } from './constants.js'
import { fmtHrs, fmtDate, todayStr } from './utils.js'
import { labelSt, inputSt, cardSt, Btn } from './ui.jsx'

export default function AttestView({ logs, totalHrs, attest, setAttest }) {
  const signRef = useRef(null)

  function save() {
    const sig = signRef.current?.value?.trim()
    if (!sig) return
    setAttest(a => ({ ...a, signed: sig, signDate: todayStr() }))
  }

  function printDoc() {
    const year = new Date().getFullYear()
    const html = `<!DOCTYPE html><html><head><title>REP Attestation ${year}</title>
    <style>body{font-family:Georgia,serif;max-width:720px;margin:60px auto;color:#111;line-height:1.7;font-size:13px}
    h1{font-size:20px;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:20px}
    h2{font-size:13px;margin-top:32px;text-transform:uppercase;letter-spacing:0.1em;border-bottom:1px solid #ccc;padding-bottom:4px}
    table{width:100%;border-collapse:collapse;font-size:11px;margin-top:12px}
    th{background:#f5f5f5;border:1px solid #ccc;padding:6px 8px;text-align:left}
    td{border:1px solid #ccc;padding:6px 8px;vertical-align:top}
    .sig{margin-top:48px;border-top:2px solid #111;padding-top:16px}
    .attest{background:#f9f9f9;border:1px solid #ccc;padding:16px;margin-top:12px;font-size:12px}</style>
    </head><body>
    <h1>Real Estate Professional Hour Log — Tax Year ${year}</h1>
    <p><strong>Taxpayer:</strong> ${attest.name}</p>
    <p><strong>Entity:</strong> ${attest.entityName}</p>
    <p><strong>Total Hours Logged:</strong> ${totalHrs.toFixed(2)}</p>
    <p><strong>IRS 750-Hour Threshold:</strong> ${totalHrs >= 750 ? '✓ Met (qualified)' : 'Not yet met'}</p>
    <h2>Hour Log Detail</h2>
    <table><thead><tr><th>Date</th><th>Category</th><th>Activity</th><th>Property</th><th>Hours</th><th>Description of Work</th></tr></thead>
    <tbody>${logs.map(l => {
      const cat = CATEGORIES.find(c => c.id === l.category)?.label || l.category
      return `<tr><td>${fmtDate(l.date)}</td><td>${cat}</td><td>${l.activity}</td><td>${l.property}</td><td>${fmtHrs(l.durationMs)}</td><td>${l.description || '—'}</td></tr>`
    }).join('')}</tbody></table>
    <h2>Declaration Under Penalty of Perjury</h2>
    <div class="attest">I, <strong>${attest.name}</strong>, declare under penalty of perjury that the information in this Real Estate Professional Hour Log is true, correct, and complete to the best of my knowledge and belief. The activities recorded were performed by me in connection with real property trade or business activities as defined under IRC §469(c)(7). During tax year ${year}, I spent more than 750 hours in real property trades or businesses in which I materially participated, and more than half of my personal services for the year were performed in real property trades or businesses in which I materially participated.</div>
    <div class="sig">
    <p style="font-size:22px;font-style:italic;margin-bottom:4px">${attest.signed}</p>
    <p><strong>Printed Name:</strong> ${attest.name}</p>
    <p><strong>Title:</strong> Managing Member, ${attest.entityName}</p>
    <p><strong>Date:</strong> ${fmtDate(attest.signDate)}</p>
    </div></body></html>`
    const w = window.open('', '_blank')
    w.document.write(html)
    w.document.close()
    w.print()
  }

  return (
    <div className="scroll-area" style={{ height: '100%', paddingBottom: 80 }}>
      <div style={{ padding: '16px 16px 8px' }}>
        <div style={{ fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase', color: '#8A7E6A' }}>Year-End Attestation</div>
        <div style={{ fontSize: 12, color: '#5A5040', marginTop: 4 }}>Required for IRS substantiation. Sign and save with your tax documentation.</div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: '8px 16px' }}>
        {/* Taxpayer info */}
        <div style={cardSt}>
          <div style={{ fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#8A7E6A', marginBottom: 14 }}>Taxpayer Information</div>
          <label style={labelSt}>Full Legal Name</label>
          <input type="text" value={attest.name} onChange={e => setAttest(a => ({ ...a, name: e.target.value }))} style={inputSt} />
          <label style={labelSt}>Entity Name</label>
          <input type="text" value={attest.entityName} onChange={e => setAttest(a => ({ ...a, entityName: e.target.value }))} style={inputSt} />
        </div>

        {/* Declaration text */}
        <div style={{ ...cardSt, borderColor: '#2A3828' }}>
          <div style={{ fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#7EB8A4', marginBottom: 14 }}>Declaration Under Penalty of Perjury</div>
          <div style={{ fontSize: 12, color: '#B8C8B0', lineHeight: 1.8, background: '#0F1510', border: '1px solid #1E2820', borderRadius: 6, padding: 16 }}>
            I, <strong style={{ color: '#E8E2D8' }}>{attest.name || '[Your Name]'}</strong>, declare under penalty of perjury that the information in this Real Estate Professional Hour Log is true, correct, and complete to the best of my knowledge and belief.
            <br /><br />
            The activities recorded were performed by me in connection with real property trade or business activities as defined under <strong style={{ color: '#E8E2D8' }}>IRC §469(c)(7)</strong>. During tax year <strong style={{ color: '#E8E2D8' }}>{new Date().getFullYear()}</strong>, I spent more than 750 hours in real property trades or businesses in which I materially participated, and more than half of my total personal services for the year were performed in real property trades or businesses in which I materially participated.
            <br /><br />
            Total hours logged: <strong style={{ color: '#C8A96E' }}>{totalHrs.toFixed(2)} hours</strong><br />
            Entity: <strong style={{ color: '#E8E2D8' }}>{attest.entityName || '[Entity]'}</strong><br />
            Role: <strong style={{ color: '#E8E2D8' }}>Managing Member</strong>
          </div>
        </div>

        {/* Signature */}
        <div style={cardSt}>
          <div style={{ fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#8A7E6A', marginBottom: 14 }}>Signature</div>
          {attest.signed ? (
            <div>
              <div style={{ fontSize: 10, color: '#5A5040', marginBottom: 8 }}>Signed {fmtDate(attest.signDate)}</div>
              <div style={{ fontSize: 28, color: '#C8A96E', borderBottom: '1px solid #4A4030', paddingBottom: 8, marginBottom: 12, fontStyle: 'italic' }}>{attest.signed}</div>
              <div style={{ fontSize: 12, color: '#8A7E6A' }}>{attest.name} — Managing Member, {attest.entityName}</div>
              <button onClick={() => setAttest(a => ({ ...a, signed: '', signDate: '' }))} style={{ marginTop: 14, background: 'none', border: '1px solid #2A2820', color: '#8A7E6A', cursor: 'pointer', fontSize: 10, padding: '7px 12px', borderRadius: 4, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                Clear & Re-sign
              </button>
            </div>
          ) : (
            <div>
              <div style={{ fontSize: 12, color: '#5A5040', marginBottom: 12 }}>Type your full legal name to sign. This constitutes a declaration under penalty of perjury.</div>
              <label style={labelSt}>Type Full Name to Sign</label>
              <input ref={signRef} type="text" placeholder={attest.name || 'Full legal name...'} style={{ ...inputSt, fontSize: 18, fontStyle: 'italic', borderColor: '#C8A96E' }} />
              <Btn onClick={save}>Sign Attestation</Btn>
            </div>
          )}
        </div>

        <button
          onClick={printDoc}
          disabled={!attest.signed}
          style={{ width: '100%', padding: 14, background: 'transparent', color: attest.signed ? '#C8A96E' : '#3A3020', border: `1px solid ${attest.signed ? '#C8A96E' : '#2A2820'}`, borderRadius: 6, fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', cursor: attest.signed ? 'pointer' : 'not-allowed', marginBottom: 4 }}
        >
          Print / Save as PDF
        </button>
        {!attest.signed && <div style={{ fontSize: 11, color: '#5A5040', textAlign: 'center', marginBottom: 8 }}>Sign above before printing</div>}
      </div>
    </div>
  )
}
