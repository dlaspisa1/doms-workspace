import { useState, useEffect, useRef } from 'react'
import { CATEGORIES } from './constants.js'
import { LS, todayStr, weekKey, weeksSince, fmtHrs, formatDuration, exportCSV } from './utils.js'
import { PROPERTIES } from './constants.js'
import LogView from './LogView.jsx'
import RecurView from './RecurView.jsx'
import SummaryView from './SummaryView.jsx'
import AttestView from './AttestView.jsx'

const NAV = [
  { id: 'log',     icon: '⏱', label: 'Log' },
  { id: 'recur',   icon: '↻', label: 'Recurring' },
  { id: 'summary', icon: '📊', label: 'Summary' },
  { id: 'attest',  icon: '📝', label: 'Attest' },
]

export default function App() {
  const [logs,   setLogs]   = useState(() => LS.get('rep_logs', []))
  const [recur,  setRecur]  = useState(() => LS.get('rep_recur', []))
  const [attest, setAttest] = useState(() => LS.get('rep_attest', { name: 'Dominick', entityName: 'DFM Capital LLC', signed: '', signDate: '' }))
  const [timer,  setTimer]  = useState(null)
  const [elapsed, setElapsed] = useState(0)
  const [view,   setView]   = useState('log')
  const [form,   setForm]   = useState({ category: '', activity: '', property: PROPERTIES[3], description: '', notes: '', date: todayStr(), mh: '', mm: '' })
  const tick = useRef(null)

  // Persist to localStorage
  useEffect(() => { LS.set('rep_logs',   logs)   }, [logs])
  useEffect(() => { LS.set('rep_recur',  recur)  }, [recur])
  useEffect(() => { LS.set('rep_attest', attest) }, [attest])

  // Auto-log recurring tasks
  useEffect(() => {
    if (!recur.length) return
    const newEntries = []
    recur.forEach(task => {
      weeksSince(task.startDate).forEach(date => {
        const wk = weekKey(date)
        if (!logs.some(l => l.recurId === task.id && l.wk === wk)) {
          newEntries.push({
            id: Date.now() + Math.random(), date,
            category: task.category, activity: task.activity,
            property: task.property, description: task.description,
            notes: task.notes, durationMs: task.durationMs,
            method: 'recurring', recurId: task.id, wk
          })
        }
      })
    })
    if (newEntries.length) setLogs(prev => [...newEntries, ...prev].sort((a, b) => b.date.localeCompare(a.date)))
  }, [recur]) // eslint-disable-line

  // Timer tick
  useEffect(() => {
    if (timer) { tick.current = setInterval(() => setElapsed(Date.now() - timer.startMs), 1000) }
    else { clearInterval(tick.current); setElapsed(0) }
    return () => clearInterval(tick.current)
  }, [timer])

  const totalMs  = logs.reduce((a, l) => a + l.durationMs, 0)
  const totalHrs = totalMs / 3600000
  const doy = Math.ceil((new Date() - new Date(new Date().getFullYear(), 0, 1)) / 86400000)
  const onPace = totalHrs / (doy / 365) >= 750

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#0F0E0C' }}>

      {/* ── Header ── */}
      <div style={{ background: '#0F0E0C', borderBottom: '1px solid #2A2820', padding: '14px 16px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 9, letterSpacing: '0.25em', textTransform: 'uppercase', color: '#5A5040', marginBottom: 2 }}>DFM Capital LLC</div>
            <div style={{ fontSize: 18, color: '#E8E2D8', lineHeight: 1.1 }}>REP Hour Log</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 28, fontWeight: 'bold', color: '#C8A96E', lineHeight: 1 }}>
              {totalHrs.toFixed(1)}<span style={{ fontSize: 12, color: '#8A7E6A', marginLeft: 3 }}>/ 750h</span>
            </div>
            <div style={{ fontSize: 9, letterSpacing: '0.15em', textTransform: 'uppercase', color: onPace ? '#7EB8A4' : '#C87E8A', marginTop: 2 }}>
              {onPace ? '● On pace' : '● Behind pace'}
            </div>
          </div>
        </div>
        {/* Progress bar */}
        <div style={{ height: 3, background: '#2A2820', borderRadius: 2, marginTop: 12 }}>
          <div style={{ height: 3, borderRadius: 2, background: 'linear-gradient(90deg,#C8A96E,#E8C98E)', width: `${Math.min((totalHrs / 750) * 100, 100)}%`, transition: 'width 0.5s' }} />
        </div>
        {/* Running timer pill */}
        {timer && (
          <div style={{ marginTop: 10, background: '#1A1810', borderRadius: 6, padding: '8px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: 10, color: '#C8A96E', letterSpacing: '0.1em', textTransform: 'uppercase' }}>⏱ Timer running</div>
            <div style={{ fontSize: 22, color: '#C8A96E', fontVariantNumeric: 'tabular-nums' }}>{formatDuration(elapsed)}</div>
          </div>
        )}
      </div>

      {/* ── Main content ── */}
      <div style={{ flex: 1, overflow: 'hidden' }}>
        {view === 'log'     && <LogView     logs={logs} setLogs={setLogs} form={form} setForm={setForm} timer={timer} setTimer={setTimer} elapsed={elapsed} />}
        {view === 'recur'   && <RecurView   recur={recur} setRecur={setRecur} setLogs={setLogs} />}
        {view === 'summary' && <SummaryView logs={logs} totalHrs={totalHrs} totalMs={totalMs} exportCSV={() => exportCSV(logs, CATEGORIES)} />}
        {view === 'attest'  && <AttestView  logs={logs} totalHrs={totalHrs} attest={attest} setAttest={setAttest} />}
      </div>

      {/* ── Bottom nav ── */}
      <nav className="bottom-nav">
        {NAV.map((n, i) => {
          const label = n.id === 'recur'  ? `Recurring${recur.length ? ` (${recur.length})` : ''}` :
                        n.id === 'attest' ? (attest.signed ? '✓ Attest' : 'Attest') : n.label
          const icon  = n.id === 'attest' && attest.signed ? '✅' : n.icon
          return (
            <button key={n.id} className={`nav-item${view === n.id ? ' active' : ''}`} onClick={() => setView(n.id)}>
              <span className="nav-icon">{icon}</span>
              <span>{label}</span>
            </button>
          )
        })}
      </nav>
    </div>
  )
}
