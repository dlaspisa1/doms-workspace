import { CATEGORIES } from './constants.js'
import { fmtHrs } from './utils.js'

export default function SummaryView({ logs, totalHrs, totalMs, exportCSV }) {
  return (
    <div className="scroll-area" style={{ height: '100%', paddingBottom: 80 }}>
      <div style={{ padding: '16px 16px 8px' }}>
        <div style={{ fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase', color: '#8A7E6A', marginBottom: 14 }}>
          Hours by Category — {new Date().getFullYear()}
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '0 16px' }}>
        {CATEGORIES.map(c => {
          const ms = logs.filter(l => l.category === c.id).reduce((a, l) => a + l.durationMs, 0)
          return (
            <div key={c.id} style={{ background: '#161510', border: '1px solid #2A2820', borderRadius: 10, padding: '14px 16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 13, color: c.color }}>{c.icon} {c.label}</span>
                <span style={{ fontSize: 16, color: '#E8E2D8', fontVariantNumeric: 'tabular-nums' }}>{(ms / 3600000).toFixed(2)}h</span>
              </div>
              <div style={{ height: 3, background: '#2A2820', borderRadius: 2 }}>
                <div style={{ height: 3, borderRadius: 2, background: c.color, width: totalMs ? `${(ms / totalMs) * 100}%` : '0%', transition: 'width 0.4s' }} />
              </div>
              <div style={{ fontSize: 10, color: '#5A5040', marginTop: 5 }}>
                {totalMs ? `${((ms / totalMs) * 100).toFixed(1)}% of total` : '—'}
              </div>
              {ms > 0 && (
                <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid #1E1C18' }}>
                  {c.activities.map(act => {
                    const ams = logs.filter(l => l.category === c.id && l.activity === act).reduce((a, l) => a + l.durationMs, 0)
                    if (!ams) return null
                    return (
                      <div key={act} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: '#8A7E6A', marginTop: 4, gap: 8 }}>
                        <span style={{ flex: 1 }}>{act}</span>
                        <span style={{ color: '#E8E2D8', flexShrink: 0 }}>{(ams / 3600000).toFixed(2)}h</span>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}

        <div style={{ background: '#161510', border: '1px solid #C8A96E', borderRadius: 10, padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div>
            <div style={{ fontSize: 10, color: '#8A7E6A', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Total Logged</div>
            <div style={{ fontSize: 28, color: '#C8A96E', marginTop: 4 }}>{totalHrs.toFixed(2)} hrs</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 10, color: '#8A7E6A', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Remaining</div>
            <div style={{ fontSize: 28, color: totalHrs >= 750 ? '#7EB8A4' : '#E8E2D8', marginTop: 4 }}>
              {totalHrs >= 750 ? '✓ Done' : `${(750 - totalHrs).toFixed(1)} hrs`}
            </div>
          </div>
        </div>

        <button onClick={exportCSV} style={{ width: '100%', padding: 14, background: 'transparent', color: '#8A7E6A', border: '1px solid #2A2820', borderRadius: 6, fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', cursor: 'pointer', marginBottom: 8 }}>
          Export CSV
        </button>
      </div>
    </div>
  )
}
