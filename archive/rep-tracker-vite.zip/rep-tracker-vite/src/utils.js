export function formatDuration(ms) {
  const s = Math.floor(ms / 1000)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
}

export function fmtHrs(ms) {
  return (ms / 3600000).toFixed(2)
}

export function todayStr() {
  return new Date().toISOString().split('T')[0]
}

export function weekKey(dateStr) {
  const d = new Date(dateStr + 'T00:00:00')
  const jan1 = new Date(d.getFullYear(), 0, 1)
  const week = Math.ceil(((d - jan1) / 86400000 + jan1.getDay() + 1) / 7)
  return `${d.getFullYear()}-W${String(week).padStart(2, '0')}`
}

export function weeksSince(startDate) {
  const dates = []
  const start = new Date(startDate + 'T00:00:00')
  const today = new Date(todayStr() + 'T00:00:00')
  let cur = new Date(start)
  while (cur <= today) {
    dates.push(cur.toISOString().split('T')[0])
    cur.setDate(cur.getDate() + 7)
  }
  return dates
}

export function fmtDate(str) {
  if (!str) return ''
  const [y, m, d] = str.split('-')
  return `${m}/${d}/${y}`
}

export const LS = {
  get: (k, d) => {
    try {
      const v = localStorage.getItem(k)
      return v ? JSON.parse(v) : d
    } catch { return d }
  },
  set: (k, v) => {
    try { localStorage.setItem(k, JSON.stringify(v)) } catch {}
  }
}

export function exportCSV(logs, CATEGORIES) {
  const rows = logs.map(l => {
    const cat = CATEGORIES.find(c => c.id === l.category)?.label || l.category
    return `"${l.date}","${cat}","${l.activity}","${l.property}","${fmtHrs(l.durationMs)}","${l.description || ''}","${l.notes || ''}","${l.method}"`
  })
  const blob = new Blob(
    ['Date,Category,Activity,Property,Hours,Description of Work,Notes,Method\n' + rows.join('\n')],
    { type: 'text/csv' }
  )
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = `REP_Hours_${new Date().getFullYear()}.csv`
  a.click()
}
