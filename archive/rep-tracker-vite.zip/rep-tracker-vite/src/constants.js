export const CATEGORIES = [
  {
    id: 'acquisition', label: 'Acquisition & Disposition', icon: '🏗', color: '#C8A96E',
    activities: ['Property search & analysis','Due diligence review','Offer preparation & negotiation','Contract review & execution','Closing coordination','Title & escrow communication','Broker/agent meetings','Disposition / sale preparation']
  },
  {
    id: 'development', label: 'Development & Construction', icon: '🔨', color: '#7EB8A4',
    activities: ['Contractor sourcing & bidding','Construction oversight / site visits','Permit coordination','Architectural / design review','Renovation project management','Zoning & entitlement research']
  },
  {
    id: 'management', label: 'Property Management', icon: '🏠', color: '#8FA8C8',
    activities: ['Tenant communication','Lease negotiation & execution','Rent collection / Section 8 coordination','Maintenance coordination','Vendor management','Move-in / move-out inspections','Eviction proceedings','Property walk-throughs']
  },
  {
    id: 'leasing', label: 'Rental & Leasing', icon: '🔑', color: '#C87E8A',
    activities: ['Listing preparation & marketing','Showing units to prospective tenants','Tenant screening & background checks','Lease drafting & review','Vacancy analysis']
  },
  {
    id: 'finance', label: 'Finance & Accounting', icon: '📊', color: '#A08CC8',
    activities: ['Bookkeeping & expense tracking','Loan / financing research','Lender communication','Insurance review & coordination','Tax planning & CPA meetings','Financial statement review','Investor reporting']
  },
  {
    id: 'legal', label: 'Legal & Compliance', icon: '⚖️', color: '#C8A07E',
    activities: ['Attorney communication','Contract drafting / review','Landlord-tenant law research','Entity / LLC administration','FIRPTA / tax compliance','Dispute resolution']
  },
  {
    id: 'education', label: 'Education & Professional Development', icon: '📚', color: '#7EC8B4',
    activities: ['Real estate market research','Industry courses / webinars','Networking with professionals','Reading trade publications']
  },
]

export const PROPERTIES = [
  '433–439 W. Osborn Rd, Phoenix',
  '2702 E. Juniper (sold duplex)',
  '14515 E Prairie Dog Trail, Fountain Hills',
  'General / Portfolio-wide',
  'Other',
]
