# REP Hour Tracker — PWA

Real Estate Professional hour log for IRS §469(c)(7) substantiation.
Built with Vite + React. Installable as a PWA on iPhone and Android.

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

## Build for production

```bash
npm run build
npm run preview   # preview the production build locally
```

The `dist/` folder is what you deploy.

## Deploy (free options)

### Netlify (easiest)
1. Run `npm run build`
2. Go to netlify.com → drag and drop the `dist/` folder
3. Done — you get an HTTPS URL instantly

### GitHub Pages
1. Push to a GitHub repo
2. Settings → Pages → select `dist/` as source
3. Or use the `gh-pages` npm package for one-command deploys

## Install on iPhone
1. Open the deployed HTTPS URL in Safari
2. Tap the Share button (box with arrow)
3. Tap "Add to Home Screen"
4. Name it and tap Add

The app will work offline after the first load.

## Project Structure

```
src/
  main.jsx        # Entry point
  App.jsx         # Root component, state management, routing
  LogView.jsx     # Log hours tab
  RecurView.jsx   # Recurring weekly tasks tab
  SummaryView.jsx # Hours summary by category
  AttestView.jsx  # Year-end IRS attestation + print
  constants.js    # Categories, activities, properties
  utils.js        # Helpers, localStorage wrapper, CSV export
  ui.jsx          # Shared UI primitives (Btn, Tag, styles)
  index.css       # Global styles, bottom nav, PWA layout
```

## Adding a Backend (next step)

When you're ready to persist data in the cloud instead of localStorage:
- **Supabase** (free tier) — drop-in Postgres with a JS client
- **Firebase Firestore** — Google's realtime DB

Replace the `LS.get/set` calls in `App.jsx` with your DB reads/writes.

## Notes for CPA
- Export CSV from the Summary tab for year-end documentation
- Print the signed Attestation from the Attest tab
- The attestation PDF includes the full hour log table + IRC §469(c)(7) declaration
